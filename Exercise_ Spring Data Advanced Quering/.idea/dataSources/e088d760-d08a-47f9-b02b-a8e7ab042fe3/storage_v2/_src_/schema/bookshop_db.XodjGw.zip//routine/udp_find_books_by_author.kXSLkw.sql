create procedure udp_find_books_by_author(IN first_name varchar(255), IN last_name varchar(255), OUT books_count int)
  BEGIN
    SET books_count = (SELECT COUNT(*) AS books
                       FROM `books` AS b
                              JOIN `authors` AS a ON b.author_id = a.id
                       WHERE a.first_name = first_name
                         AND a.last_name = last_name
                       GROUP BY a.id);
  END;

