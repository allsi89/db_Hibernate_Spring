create procedure usp_get_older(IN id int)
  BEGIN
                    START TRANSACTION;
                    UPDATE minions m
                        SET m.age = m.age + 1
                    WHERE m.id = id;
                    IF(SELECT count(m2.id)
                      FROM minions m2
                    WHERE m2.id = id ) > 0
                      THEN commit;
                      ELSE rollback;
                   END IF;
                  end;

